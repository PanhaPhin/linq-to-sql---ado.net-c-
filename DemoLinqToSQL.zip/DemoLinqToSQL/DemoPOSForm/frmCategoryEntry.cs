﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoPOSForm
{
    public partial class frmCategoryEntry : Form
    {
        public frmCategoryEntry()
        {
            InitializeComponent();
        }

        private POSDBDataContext db = new POSDBDataContext();   

        private void frmCategoryEntry_Load(object sender, EventArgs e)
        {
            Clear();
        }

        private void Clear()
        {
            txtCategoryId.Text = "";
            txtCategoryName.Text = "";
            txtCategoryId.Text = GetLatestId().ToString();
        }

        private int GetLatestId()
        {
            var category = db.Categories
                .OrderByDescending(c => c.CategoryId)
                .FirstOrDefault();
            if (category != null)
                return category.CategoryId + 1;
            return 1;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string categoryName = txtCategoryName.Text;
            Category category = new Category();
            category.CategoryId = GetLatestId();
            category.CategoryName = categoryName;
            category.Created = DateTime.Now;
            category.Updated = DateTime.Now;
            db.Categories.InsertOnSubmit(category);
            db.SubmitChanges();
            MessageBox.Show("Add Success");

            Clear();
        }

        private void btnGetData_Click(object sender, EventArgs e)
        {
            frmCategoryList categoryList = new frmCategoryList();
            categoryList.categoryEntry = this;
            categoryList.ShowDialog();
        }

        public void LoadCategory(int categoryId)
        {
            var category = db.Categories
                .Where(c => c.CategoryId == categoryId)
                .FirstOrDefault();
            if(category != null)
            {
                txtCategoryId.Text = category.CategoryId.ToString();
                txtCategoryName.Text = category.CategoryName;
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int categoryId = int.Parse(txtCategoryId.Text);
            string newCategoryName = txtCategoryName.Text;

            var category = db.Categories
                            .Where(c=> c.CategoryId == categoryId)
                            .FirstOrDefault();
            if (category != null) 
            {
                category.CategoryName = newCategoryName;
                category.Updated = DateTime.Now;
                db.SubmitChanges();
                MessageBox.Show("Update successful!");
                Clear();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int categoryId = int.Parse(txtCategoryId.Text);

            var category = db.Categories
                            .Where(c => c.CategoryId == categoryId)
                            .FirstOrDefault();
            if (category != null)
            {
                db.Categories.DeleteOnSubmit(category);
                db.SubmitChanges();
                MessageBox.Show("Delete successful!");
                Clear();
            }
        }
    }
}
