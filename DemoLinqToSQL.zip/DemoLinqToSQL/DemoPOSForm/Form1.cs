﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoPOSForm
{
    public partial class Form1 : Form
    {
        private POSDBDataContext db = new POSDBDataContext();   
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            Employee emp = db.Employees
                        .Where(ep => ep.Username == username && 
                                     ep.Password == password)
                        .FirstOrDefault();
            if (emp != null) 
            {
                //employee exist
                //open new window form
                frmMain frm = new frmMain();
                frm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Username or password incorrect");
            }
        }
    }
}
