﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoPOSForm
{
    public partial class frmCategoryList : Form
    {
        public frmCategoryList()
        {
            InitializeComponent();
        }

        private POSDBDataContext db = new POSDBDataContext();

        private void frmCategoryList_Load(object sender, EventArgs e)
        {
            dgvCategory.DataSource = db.Categories;
        }

        public frmCategoryEntry categoryEntry = null;
        private void dgvCategory_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (categoryEntry == null)
                return;

            int count = dgvCategory.SelectedRows.Count;
            if (count > 0) 
            {
                int id = (int)dgvCategory.SelectedRows[0].Cells[0].Value;
                categoryEntry.LoadCategory(id);
                this.Close();
            }
        }
    }
}
