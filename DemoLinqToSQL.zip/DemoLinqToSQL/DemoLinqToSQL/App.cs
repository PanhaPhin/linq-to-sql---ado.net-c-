﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoLinqToSQL
{
    internal class App
    {
        private MPOSDBDataContext  db = new MPOSDBDataContext();    

        public void Run()
        {
            CrudOperation crud = new CrudOperation();
            //crud.InsertData();
            //crud.UpdateData();
            crud.DeleteData();
        }
    }
}
