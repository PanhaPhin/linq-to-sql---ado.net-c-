﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoLinqToSQL
{
    internal class CrudOperation
    {
        private MPOSDBDataContext db = new MPOSDBDataContext();

        public void Read()
        {
            foreach (Category c in db.Categories)
            {
                Console.WriteLine("name : " + c.CategoryName);
            }
        }
        public void InsertData()
        {
            Category category = new Category();
            category.CategoryId = 100;
            category.CategoryName = "new category 100";
            category.Created = DateTime.Now;
            category.Updated = DateTime.Now;

            db.Categories.InsertOnSubmit(category);
            db.SubmitChanges();
            Console.WriteLine("insert success");
        }

        public void UpdateData()
        {
            Category category = db.Categories
                            .Where(c => c.CategoryId == 100)
                            .FirstOrDefault();
           
            //select top 1 * from Category Where CategoryId = 100;
            if (category != null) 
            {
                category.CategoryName = "update category5000";
                category.Updated = DateTime.Now;
                db.SubmitChanges();
                Console.WriteLine("update successful!");
            }
        }

        public void DeleteData()
        {
            var category = db.Categories
                        .Where(c => c.CategoryId == 100)
                        .FirstOrDefault();
            if (category != null)
            {
                db.Categories.DeleteOnSubmit(category);
                db.SubmitChanges();
                Console.WriteLine("delete successful!");
            }
        }
    }
}
